"""Hourly gzip JSONL tapes.

Each line is its own gzip member, appended to `YYYYMMDD/HH.jsonl.gz` (UTC).
The member is closed on every write, so a crash loses at most the line in
flight and a reader can open the current hour while it is still being written.
"""

from __future__ import annotations

import gzip
import json
from datetime import datetime, timezone
from pathlib import Path

from pmbot.clock import Clock


def hour_key(moment: datetime) -> str:
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return moment.astimezone(timezone.utc).strftime("%Y%m%dT%H")


def read_jsonl_gz(path: Path) -> list[dict]:
    records: list[dict] = []
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


class HourlyJsonl:
    def __init__(self, root: Path, clock: Clock | None = None) -> None:
        self.root = root
        self.clock = clock or Clock()
        self.root.mkdir(parents=True, exist_ok=True)

    def write(self, record: dict) -> Path:
        if "recv_wall" not in record or "recv_monotonic_ns" not in record:
            raise ValueError("stored messages require recv_wall and recv_monotonic_ns")
        moment = self.clock.wall().astimezone(timezone.utc)
        directory = self.root / moment.strftime("%Y%m%d")
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"{moment.strftime('%H')}.jsonl.gz"
        line = json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n"
        with gzip.open(path, "ab") as handle:
            handle.write(line.encode("utf-8"))
        return path

    def close(self) -> None:
        return None
