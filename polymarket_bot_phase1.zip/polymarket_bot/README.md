# pmbot — Phase 1

Public Polymarket market discovery and order-book recorder. It does not sign or send orders. `live_trading: true` is refused.

## What was verified live (2026-10-03)

`scripts/probe.py` called the public endpoints and saved raw bodies under `data/probe/20261003T124434Z/`.

| Call | Result |
|---|---|
| `GET https://clob.polymarket.com/ok` | `200`, body `"OK"` (text, including quotes) |
| `GET https://clob.polymarket.com/time` | `200`, body `1791031474` (unix seconds, text) |
| `GET https://gamma-api.polymarket.com/markets?closed=false&limit=50` | `200`, JSON list. `clobTokenIds`, `outcomes`, and `outcomePrices` are JSON strings |
| `GET https://clob.polymarket.com/book?token_id=...` | keys `market`, `asset_id`, `timestamp`, `hash`, `bids`, `asks`, `min_order_size`, `tick_size`, `neg_risk`, `last_trade_price` |
| `GET https://clob.polymarket.com/fee-rate?token_id=...` | `{"base_fee": 1000}` |
| `wss://ws-subscriptions-clob.polymarket.com/ws/market` for 60s | text `PING` every 10s got text `PONG` (5). Events: `book` 2, `new_market` 31 |

On that book, bids were sorted ascending and asks descending. Index 0 is not the best price. Top of book uses max bid and min ask. The docs do not specify sort order.

Gamma `feeSchedule` on the same market was `{rate: 0.04, exponent: 1, takerOnly: true, rebateRate: 0.25}` with `makerBaseFee`/`takerBaseFee` 1000. `base_fee` matches the base-fee fields, not `feeSchedule.rate`. Phase 1 stores both and does not compute a fee.

`SubscriptionRequest.assets_ids` in [asyncapi.json](https://docs.polymarket.com/asyncapi.json) has no `maxItems`. The default is one WebSocket. Set `ws_assets_per_connection` to shard; a market's tokens are not split across sockets.

## Run

Python 3.11+. From this directory:

```bash
uv venv --python 3.11 .venv
uv pip install --python .venv/bin/python -e ".[dev]"
.venv/bin/python scripts/probe.py
.venv/bin/python scripts/discover.py
.venv/bin/python scripts/record.py --seconds 120
.venv/bin/pytest
```

`discover.py` writes `data/catalog.sqlite` (WAL) and fee-rate payloads. `record.py` adds a bootstrap `GET /book` per token, then the market socket. Tape files are `data/books/YYYYMMDD/HH.jsonl.gz` (UTC). Every record has `recv_wall` and `recv_monotonic_ns`.

On a socket drop after a successful subscribe, the recorder writes a `gap` record, reconnects, resubscribes, and re-snapshots that connection's tokens with `GET /book` (`reason=reconnect`). A failed first connect does not write a gap. A clean stop does not write a gap.

## Not in this phase

No paper fills, no strategy, no live orders, no gas, no slippage model. Fee math is not applied. `custom_feature_enabled` also delivers global `new_market` / `market_resolved` events, not only the subscribed tokens. Receive time is local read time; the exchange timestamp stays inside the payload. A crash can truncate the gzip member being written. Parquet is not produced.
