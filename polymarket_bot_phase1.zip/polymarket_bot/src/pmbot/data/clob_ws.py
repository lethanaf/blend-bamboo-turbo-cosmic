"""Market-channel client.

Subscribe: {"assets_ids", "type": "market", "custom_feature_enabled"}
Heartbeat: text frame PING every 10 seconds; server answers PONG.
Protocol-level ping is disabled so keepalive matches the docs.
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import Awaitable, Callable

import websockets

log = logging.getLogger(__name__)

OnMessage = Callable[[str, str], Awaitable[None]]
OnDisconnect = Callable[[str, list[str], str], Awaitable[None]]
OnSubscribed = Callable[[str, list[str], bool], Awaitable[None]]


class MarketConnection:
    def __init__(
        self,
        url: str,
        connection_id: str,
        asset_ids: list[str],
        *,
        custom_feature_enabled: bool,
        ping_interval_s: float,
        stale_s: float,
        backoff_initial_s: float,
        backoff_max_s: float,
        on_message: OnMessage,
        on_disconnect: OnDisconnect,
        on_subscribed: OnSubscribed,
    ) -> None:
        if not asset_ids:
            raise ValueError("asset_ids is empty")
        self.url = url
        self.connection_id = connection_id
        self.asset_ids = list(asset_ids)
        self.custom_feature_enabled = custom_feature_enabled
        self.ping_interval_s = ping_interval_s
        self.stale_s = stale_s
        self.backoff_initial_s = backoff_initial_s
        self.backoff_max_s = backoff_max_s
        self.on_message = on_message
        self.on_disconnect = on_disconnect
        self.on_subscribed = on_subscribed
        self.was_subscribed = False

    async def run(self, stop: asyncio.Event) -> None:
        backoff = self.backoff_initial_s
        while not stop.is_set():
            try:
                await self._one(stop)
                return
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                log.warning("ws %s failed: %s", self.connection_id, exc)
                if self.was_subscribed:
                    await self.on_disconnect(
                        self.connection_id,
                        list(self.asset_ids),
                        f"{type(exc).__name__}: {exc}",
                    )
                if await self._sleep(stop, backoff):
                    return
                backoff = min(max(backoff * 2, self.backoff_initial_s), self.backoff_max_s)

    async def _one(self, stop: asyncio.Event) -> None:
        subscribe = {
            "assets_ids": self.asset_ids,
            "type": "market",
            "custom_feature_enabled": self.custom_feature_enabled,
        }
        async with websockets.connect(
            self.url,
            ping_interval=None,
            open_timeout=20,
            max_size=16 * 1024 * 1024,
        ) as ws:
            await ws.send(json.dumps(subscribe))
            is_reconnect = self.was_subscribed
            self.was_subscribed = True
            # Do not block the read loop on the reconnect REST snapshot.
            hook = asyncio.create_task(self._subscribed(is_reconnect))
            ping_task = asyncio.create_task(self._ping(ws, stop))
            try:
                while not stop.is_set():
                    raw = await self._recv(ws, stop)
                    if raw is None:
                        break
                    await self.on_message(self.connection_id, raw)
            finally:
                ping_task.cancel()
                await _drain(ping_task)
                await hook
        if not stop.is_set():
            raise ConnectionError("market socket ended")

    async def _subscribed(self, is_reconnect: bool) -> None:
        try:
            await self.on_subscribed(self.connection_id, list(self.asset_ids), is_reconnect)
        except Exception:
            log.exception("on_subscribed failed conn=%s", self.connection_id)

    async def _recv(self, ws, stop: asyncio.Event) -> str | None:
        recv_task = asyncio.create_task(ws.recv())
        stop_task = asyncio.create_task(stop.wait())
        done, pending = await asyncio.wait(
            {recv_task, stop_task},
            timeout=self.stale_s,
            return_when=asyncio.FIRST_COMPLETED,
        )
        for task in pending:
            task.cancel()
        await _drain(*pending)
        if not done or recv_task not in done:
            if not done:
                raise ConnectionError(f"no frame for {self.stale_s}s")
            return None
        message = recv_task.result()
        if isinstance(message, bytes):
            return message.decode("utf-8", errors="replace")
        return str(message)

    async def _ping(self, ws, stop: asyncio.Event) -> None:
        while not stop.is_set():
            if await self._sleep(stop, self.ping_interval_s):
                return
            await ws.send("PING")

    async def _sleep(self, stop: asyncio.Event, seconds: float) -> bool:
        if seconds <= 0:
            return stop.is_set()
        try:
            await asyncio.wait_for(stop.wait(), timeout=seconds)
            return True
        except asyncio.TimeoutError:
            return stop.is_set()


async def _drain(*tasks: asyncio.Task) -> None:
    for task in tasks:
        if not task.done():
            task.cancel()
    for task in tasks:
        try:
            await task
        except (asyncio.CancelledError, Exception):
            pass
